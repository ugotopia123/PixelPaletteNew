Made by: Alexander Spillman
Twitter: https://twitter.com/ugotopia123
Source Code: https://github.com/ugotopia123/PixelPaletteNew/tree/master/src

Welcome to Pixel Palette!
This program redraws imported images with a specific palette of colors. It can be fun to tinker around with to see what kind of pictures get generated.

Creating/importing palettes (the application directory has a "defaultPalettes" folder to start you off):
	1. Create a PNG in an art program (I use Paint.net) with a grid of pixels equal to the number of colors you want (for example 16 colors could be a PNG that's 16x1, 4x4, or 8x2).
	2. Set each pixel to one palette color until all pixels in the grid are colored to your liking.
	3. Save the picture and import it into Pixel Palette using the "Import Palette" button (you can import as many as you want).
	4. Select the palette by left-clicking its corresponding button.
	5. Delete palettes by right-clicking the corresponding button's red X.

Importing images (a palette must be selected before image importing can begin):
	1. Click the "Import Image" button.
	2. Select a PNG, JPG, or BMP image.
	3. Wait for the program to draw the image. You can see the progress bar underneath the leftmost palette.
	4. You can click and drag the image as well as zoom in and out with the scroll wheel.

Button rundown:
	1. Import Palette - Opens up a file directory for importing palettes. Only PNGs are accepted for palettes.
	2. Import Image - Opens up a file directory for importing an image to be drawn.
	3. Reset Image - Resets the currently-drawn image to its default scale and centers it on the screen.
	4. Redraw Image - Redraws the image with the currently-selected palette. Can be used to quickly update the current image with a new palette.
	5. Export Image - Opens up a file directory for saving the currently-drawn image. The image is saved as a PNG with the default name equal to the original image's name + the used palette's name.
	6. Copy Image - Copies the currently-drawn image to the clipboard.

----WARNING FOR LARGE IMAGES----
Pixel Palette is made in Flash, which means it's not the most memory-efficient program.
I tried extensively to make the program as efficient as possible but it still has memory issues when you try to import an image with immense dimensions/file sizes.
Testing has shown that the program crashes with images that have ~50 million pixels total (that's about a square image that's 7500x7500 pixels).
Crashes have also occured when trying to import images with large file sizes of about ~30MB.
If you experience crashes you should try to reduce the image sizes that you're importing.

If you're able to get the program to draw a large image but experience crashes when using the "Export Image" button,
I've had some success using the "Copy Image" button instead and pasting it in a separate art program (like Paint.net) and saving it through there.